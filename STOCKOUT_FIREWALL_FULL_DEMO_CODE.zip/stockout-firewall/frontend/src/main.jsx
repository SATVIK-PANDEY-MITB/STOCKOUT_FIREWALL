import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Mic,ChevronLeft,ChevronRight,AlertTriangle,Play,CheckCircle2,Route,ShoppingBasket,Zap,ShieldCheck,Wallet,RefreshCw} from 'lucide-react';
import './styles.css';

const API='http://localhost:8000';
const steps=['Speak','Basket','Optimize','Route','Failure','Failover','Pay'];
const baseItems=[
 {product:'Rice',quantity:50,unit:'kg',brand:'Rice'},
 {product:'Fortune Oil',quantity:5,unit:'box',brand:'Fortune'},
 {product:'Biscuits',quantity:10,unit:'packet',brand:'Parle'}
];

function App(){
 const [step,setStep]=useState(0);
 const [playing,setPlaying]=useState(false);
 const [failed,setFailed]=useState(false);
 const [replanned,setReplanned]=useState(false);
 const [items,setItems]=useState(baseItems);
 const [message,setMessage]=useState('Anna, naale 50 kilo rice beku, 5 box Fortune oil, biscuit 10 packet…');
 const [confidence,setConfidence]=useState(null);
 const [loading,setLoading]=useState(false);

 const runOptimize=async()=>{
   setLoading(true); setStep(2);
   try{
    const payload={merchant:'Ramesh Kirana',raw_text:message,items,budget:20000,price_tolerance:.05,min_reliability:.90,auto_failover:true,auto_substitution:false};
    const r=await fetch(`${API}/api/orders/ORD-DEMO-001/optimize`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const d=await r.json(); setConfidence(d.fulfillment_confidence);
   }catch(e){setConfidence(.96)} finally{setLoading(false)}
 };
 const simulateFailure=async()=>{
   setFailed(true);setStep(4);setReplanned(false);
   try{await fetch(`${API}/api/supplier-events`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({supplier_id:'SUP-A',available_quantity:40,product:'Rice'})})}catch(e){}
 };
 const failover=async()=>{
   setLoading(true);setStep(5);
   try{const r=await fetch(`${API}/api/orders/ORD-DEMO-001/replan`,{method:'POST'});const d=await r.json();setConfidence(d.fulfillment_confidence)}catch(e){setConfidence(.91)}
   setReplanned(true);setLoading(false);
 };
 const next=()=>{
  if(step===0){setStep(1);return}
  if(step===1){runOptimize();return}
  if(step===2){setStep(3);return}
  if(step===3){simulateFailure();return}
  if(step===4){failover();return}
  if(step===5){setStep(6);return}
  setStep(0);setFailed(false);setReplanned(false);
 };
 const autoPlay=async()=>{
  if(playing)return;setPlaying(true);setStep(0);setFailed(false);setReplanned(false);
  await new Promise(r=>setTimeout(r,900));setStep(1);
  await new Promise(r=>setTimeout(r,900));await runOptimize();
  await new Promise(r=>setTimeout(r,900));setStep(3);
  await new Promise(r=>setTimeout(r,900));await simulateFailure();
  await new Promise(r=>setTimeout(r,900));await failover();
  await new Promise(r=>setTimeout(r,900));setStep(6);
  await new Promise(r=>setTimeout(r,1200));setPlaying(false);
 };
 return <div className="app">
   <header className="topbar">
    <div className="brand"><strong>STOCKOUT FIREWALL</strong><span>AI procurement & fulfillment resilience · Team Jugaad Coders · HackSprint 2026 · Track 1 PS-21</span></div>
    <div className="top-actions"><button onClick={()=>setStep(Math.max(0,step-1))}><ChevronLeft size={16}/> Back</button><button onClick={next}>Next <ChevronRight size={16}/></button><button className="danger" onClick={simulateFailure}><AlertTriangle size={15}/> Supplier A fails</button><button className="play" onClick={autoPlay}><Play size={15}/> Auto-play</button></div>
   </header>
   <main className="layout">
    <section className="phone-wrap">
      <div className="phone">
       <div className="wa-head"><div className="avatar">R</div><div><b>Ramesh Kirana</b><small>Stockout Firewall · WhatsApp</small></div></div>
       <div className="chat"><div className="bubble"><div className="wave">▮▮▮▮▮▮▮▮▮▮▮▮</div><span>🎤 0:07</span> “{message}”</div>{failed&&<div className="event-bubble">⚠ Supplier A reports only <b>40 kg</b> available.</div>}{replanned&&<div className="success-bubble">✓ Backup supplier activated. Missing quantity recovered.</div>}</div>
       <div className="recording"><span className="dot"></span>{step===0?'recording':'ready'}</div>
      </div>
    </section>
    <section className="dashboard">
      <div className="stepper">{steps.map((s,i)=><button key={s} className={step===i?'active':''} onClick={()=>setStep(i)}>{i+1} {s}</button>)}</div>
      <div className="metrics">
       <Metric title="Fulfillment confidence" value={confidence?Math.round(confidence*100)+'%':'—'} icon={<ShieldCheck size={17}/>}/>
       <Metric title="Basket fulfillment" value={replanned?'100%':step>=2?'96%':'—'} icon={<ShoppingBasket size={17}/>}/>
       <Metric title="Stockout risk" value={replanned?'LOW':'LOW'} icon={<Zap size={17}/>}/>
       <Metric title="Trips / order" value={replanned?'2':step>=2?'1':'—'} icon={<Route size={17}/>}/>
      </div>
      <div className="cards">
       <InfoCard title={step===0?'LISTENING':step===1?'ORDER UNDERSTOOD':step===2?'OPTIMIZING':step===3?'DELIVERY PLAN':step===4?'FAILURE DETECTED':step===5?'FAILOVER ACTIVE':'PAYMENT READY'}>
        {step===0&&<><p>Merchant speaks in Kannada / Hindi / Tamil / Telugu / Bengali or code-mixed speech. Sarvam ASR transcribes it.</p><div className="status"><Mic size={14}/> recording</div></>}
        {step===1&&<Basket items={items}/>} 
        {step===2&&<><p>Comparing suppliers using inventory, reliability, landed cost, MOQ, delivery feasibility and merchant constraints.</p><div className="loader">{loading?'Running optimizer…':'Optimization complete ✓'}</div></>}
        {step===3&&<RoutePlan failed={false}/>} 
        {step===4&&<><div className="failure"><AlertTriangle size={18}/><div><b>Supplier A failure</b><span>Required 100 kg · available 40 kg · shortfall 60 kg</span></div></div><p>Failover engine is calculating the missing quantity and backup suppliers.</p></>}
        {step===5&&<><div className="recovery"><CheckCircle2 size={20}/><div><b>Recovery complete</b><span>Supplier B activated · 60 kg recovered · route re-optimized</span></div></div><RoutePlan failed={true}/></>}
        {step===6&&<><div className="payment"><Wallet size={21}/><div><b>One payment experience</b><span>Merchant confirms one basket. Backend coordinates supplier settlement.</span></div></div><button className="confirm" onClick={()=>setStep(0)}>Confirm procurement</button></>}
       </InfoCard>
       <InfoCard title="GUARDRAILS"><p className="guard">Budget <b>₹20,000</b> · price tolerance <b>5%</b> · min reliability <b>90%</b> · auto-failover <b>ON</b> · auto-substitution <b>OFF</b></p></InfoCard>
      </div>
      <div className="event-line"><span>●</span> {failed?'SUPPLIER_SHORTFALL → REPLAN → NEW_SUPPLIER_SELECTED → ROUTE_REOPTIMIZED':'Ready for demonstration'}</div>
    </section>
   </main>
 </div>
}
function Metric({title,value,icon}){return <div className="metric"><div className="metric-title">{icon}{title}</div><strong>{value}</strong></div>}
function InfoCard({title,children}){return <div className="info-card"><h3>{title}</h3>{children}</div>}
function Basket({items}){return <div className="basket">{items.map((x,i)=><div className="row" key={i}><span>{x.product}</span><b>{x.quantity} {x.unit}</b><em>{i===0?'SUP-A':i===1?'SUP-A':'SUP-B'}</em></div>)}</div>}
function RoutePlan({failed}){return <div className="route"><div className="route-row"><span>Supplier A</span><span>→</span><b>Ramesh Kirana</b><small>{failed?'Original rice leg replaced':'2.4 km · 18 min'}</small></div>{failed&&<div className="route-row backup"><span>Supplier B</span><span>→</span><b>Ramesh Kirana</b><small>4.1 km · backup 60 kg</small></div>}</div>}
createRoot(document.getElementById('root')).render(<App/>);
