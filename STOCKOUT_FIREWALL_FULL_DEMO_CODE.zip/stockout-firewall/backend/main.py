from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from pathlib import Path
import random

app = FastAPI(title='Stockout Firewall API', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

class OrderItem(BaseModel):
    product: str
    quantity: float
    unit: str
    brand: Optional[str] = None

class OrderRequest(BaseModel):
    merchant: str = 'Ramesh Kirana'
    raw_text: str
    items: List[OrderItem]
    budget: float = 20000
    price_tolerance: float = 0.05
    min_reliability: float = 0.90
    auto_failover: bool = True
    auto_substitution: bool = False

class SupplierEvent(BaseModel):
    supplier_id: str
    available_quantity: float
    product: str = 'Rice'

SUPPLIERS = [
    {'id':'SUP-A','name':'Sri Lakshmi Wholesale','reliability':0.96,'distance_km':2.4,'payment_terms':'Immediate','price_factor':1.00},
    {'id':'SUP-B','name':'Metro Wholesale Hub','reliability':0.93,'distance_km':4.1,'payment_terms':'7 days','price_factor':1.02},
    {'id':'SUP-C','name':'Bengaluru Trade Mart','reliability':0.91,'distance_km':5.2,'payment_terms':'Immediate','price_factor':0.98},
]

@app.get('/api/health')
def health():
    return {'status':'ok','service':'stockout-firewall'}

@app.post('/api/orders')
def create_order(order: OrderRequest):
    return {'order_id':'ORD-DEMO-001','status':'ORDER_CREATED','merchant':order.merchant,'items':[i.model_dump() for i in order.items]}

@app.post('/api/orders/{order_id}/optimize')
def optimize(order_id: str, order: OrderRequest):
    allocations=[]
    for item in order.items:
        remaining=item.quantity
        chosen=sorted(SUPPLIERS, key=lambda s:(-s['reliability'], s['distance_km']))
        for s in chosen:
            qty=remaining if s['id']=='SUP-A' else 0
            if qty:
                allocations.append({'supplier_id':s['id'],'supplier':s['name'],'product':item.product,'quantity':qty,'unit':item.unit,'reliability':s['reliability'],'distance_km':s['distance_km']})
                remaining-=qty
            if remaining<=0: break
    return {'order_id':order_id,'status':'OPTIMIZED','allocations':allocations,'fulfillment_confidence':0.96,'stockout_risk':'LOW','trips':1,'reason':'Highest-reliability supplier with feasible distance and confirmed inventory.'}

@app.post('/api/supplier-events')
def supplier_event(event: SupplierEvent):
    required=100.0
    shortfall=max(0, required-event.available_quantity)
    if shortfall == 0:
        return {'event':'SUPPLY_OK','shortfall':0,'status':'CONTINUE'}
    backup=[s for s in SUPPLIERS if s['id']!=event.supplier_id]
    backup=sorted(backup,key=lambda s:(-s['reliability'],s['distance_km']))
    allocations=[]
    remaining=shortfall
    for s in backup:
        qty=remaining if s['id']=='SUP-B' else 0
        if qty:
            allocations.append({'supplier_id':s['id'],'supplier':s['name'],'quantity':qty,'reliability':s['reliability']})
            remaining-=qty
        if remaining<=0: break
    return {'event':'SUPPLIER_SHORTFALL','required':required,'available':event.available_quantity,'shortfall':shortfall,'status':'REPLANNED' if remaining<=0 else 'PARTIAL','allocations':allocations,'route_reoptimized':True,'fulfillment_confidence':0.91 if remaining<=0 else 0.62}

@app.post('/api/orders/{order_id}/replan')
def replan(order_id: str):
    return {'order_id':order_id,'status':'REPLANNED','message':'Backup supplier activated and delivery route re-optimized.','fulfillment_confidence':0.91}

@app.get('/api/suppliers')
def suppliers():
    return {'suppliers':SUPPLIERS}
