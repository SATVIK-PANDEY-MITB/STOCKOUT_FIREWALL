# Stockout Firewall — Prototype Walkthrough

## Scene 1 — Merchant Interface
The UI intentionally resembles a WhatsApp conversation next to a procurement control tower.

## Scene 2 — Order Understanding
Use the supplied Kannada/code-mixed demo phrase. Demonstrate that the input becomes structured products and quantities.

## Scene 3 — Guardrails
Highlight:
- Budget ₹20,000
- Price tolerance 5%
- Minimum reliability 90%
- Auto-failover ON
- Auto-substitution OFF

## Scene 4 — Optimization
Show supplier selection and fulfillment confidence.

## Scene 5 — Failure Simulation
Trigger Supplier A failure.

Expected state:
- Required: 100 kg
- Available: 40 kg
- Shortfall: 60 kg

## Scene 6 — Recovery
Trigger Failover.

Expected state:
- Supplier B activated
- 60 kg recovered
- Route re-optimized
- Fulfillment confidence updated

## Scene 7 — Payment
Show one confirmation/payment experience.

## Recording recommendation
Record the browser at 1080p, hide browser chrome if possible, use the Auto-play button for a clean uninterrupted run, then record a second version manually showing the failure button for the judge-facing explanation.
