# Stockout Firewall — 3-Minute Demo Video Script

## 0:00–0:20 — The merchant speaks
Show the WhatsApp-style merchant panel.

Say:
> “A small merchant should not need to understand procurement systems. They should simply speak naturally.”

Play the Kannada/code-mixed order:
> “Anna, naale 50 kilo rice beku, 5 box Fortune oil, biscuit 10 packet…”

## 0:20–0:40 — AI understands the order
Show the Speak → Basket transition.

Explain:
- Multilingual/code-mixed input
- Speech recognition
- Intent/entity extraction
- SKU normalization

## 0:40–1:00 — Supplier intelligence
Show supplier data and reliability signals.

Explain that the system evaluates:
- Inventory
- Price
- MOQ
- Reliability
- Distance
- Payment terms

## 1:00–1:20 — Optimization
Show the Optimize step.

Say:
> “We do not simply select the cheapest supplier. We optimize the basket using total landed cost, reliability and fulfillment constraints.”

## 1:20–1:40 — Delivery plan
Show the Route step.

Explain direct/consolidated delivery and deadline feasibility.

## 1:40–2:00 — Supplier failure
Click “Supplier A fails”.

Show:
> Required: 100 kg · Available: 40 kg · Shortfall: 60 kg

Say:
> “This is the moment where Stockout Firewall becomes different.”

## 2:00–2:20 — Automatic failover
Show the Failover step.

Explain:
- Shortfall detected
- Backup supplier discovered
- Missing quantity allocated
- Merchant constraints preserved

## 2:20–2:40 — Route re-optimization
Show the updated route.

Say:
> “The system does not merely find another supplier. It re-solves the fulfillment plan.”

## 2:40–3:00 — One confirmation
Show Pay.

Finish with:
> “One basket. One confirmation. One payment experience. And when one supplier fails, the merchant doesn't.”
