# 🛡️ Stockout Firewall — Working Prototype

**AI procurement resilience platform for India's small merchants.**

> **When one supplier fails, the merchant shouldn't.**

This repository contains the hackathon demo prototype corresponding to the Stockout Firewall concept: multilingual merchant ordering, supplier optimization, delivery planning, supplier failure simulation, automatic failover and re-optimization.

## What the prototype demonstrates

1. WhatsApp-style merchant voice/text order
2. Structured basket representation
3. Supplier/reliability-aware optimization state
4. Delivery planning
5. Supplier A failure simulation
6. Automatic backup supplier activation
7. Route re-optimization
8. One payment/confirmation experience
9. Demo Auto-play mode for video recording

## Run locally

### Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Backend: `http://localhost:8000`

API docs: `http://localhost:8000/docs`

### Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

### Docker

```bash
docker compose up --build
```

## Demo controls

- **Back / Next:** move through the seven demo stages.
- **Supplier A fails:** immediately triggers the failure state.
- **Auto-play:** runs the complete judge-facing flow automatically.

## Seven stages

```text
1 Speak
2 Basket
3 Optimize
4 Route
5 Failure
6 Failover
7 Pay
```

## Important prototype note

The hackathon version intentionally uses deterministic mock supplier data for repeatable demonstrations. The architecture is ready to connect real Sarvam ASR, LLM orchestration, maps/routing, supplier feeds and payment sandbox integrations through environment variables and backend adapters.

See:

- `docs/DEMO_VIDEO_SCRIPT.md`
- `docs/PROTOTYPE_VIDEO_SCRIPT.md`
- `data/suppliers.json`

## Architecture

```text
Merchant
  ↓
Voice/Text
  ↓
Order Understanding
  ↓
SKU Normalization
  ↓
Supplier Intelligence
  ↓
Basket Optimization
  ↓
Route Optimization
  ↓
Fulfillment
  ↓
Failure Detection
  ↓
Failover
  ↓
Re-optimization
```

## Tech stack

- React + Vite
- FastAPI
- Python
- REST APIs
- Deterministic demo supplier engine
- Responsive HTML/CSS
- Lucide icons

## Production integration points

- Sarvam ASR / language APIs
- LLM orchestration
- PostgreSQL
- Redis
- OR-Tools / CP-SAT
- Google Maps / Mapbox
- WhatsApp Business API
- UPI/payment sandbox
- LightGBM/XGBoost for prediction

## Core engineering principle

> **LLM ≠ Decision Engine**

The LLM can understand and orchestrate. Authoritative inventory, prices, reliability, optimization, routing, policies and payment authorization remain deterministic and auditable.
